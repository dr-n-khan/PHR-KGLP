from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Tuple, Set
import pandas as pd
import numpy as np

@dataclass
class KGData:
    entities: List[str]
    relations: List[str]
    ent2id: Dict[str, int]
    rel2id: Dict[str, int]
    triples: np.ndarray
    triple_set: Set[Tuple[int, int, int]]

def load_triples_csv(path: str, sep: str, head_col: str, rel_col: str, tail_col: str) -> pd.DataFrame:
    df = pd.read_csv(path, sep=sep)
    df = df[[head_col, rel_col, tail_col]].rename(columns={head_col: "head", rel_col: "rel", tail_col: "tail"})
    df = df.dropna()
    df["head"] = df["head"].astype(str)
    df["rel"] = df["rel"].astype(str)
    df["tail"] = df["tail"].astype(str)
    return df

def build_kg(df: pd.DataFrame) -> KGData:
    entities = sorted(set(df["head"]).union(set(df["tail"])))
    relations = sorted(set(df["rel"]))
    ent2id = {e: i for i, e in enumerate(entities)}
    rel2id = {r: i for i, r in enumerate(relations)}
    triples = np.stack([
        df["head"].map(ent2id).values,
        df["rel"].map(rel2id).values,
        df["tail"].map(ent2id).values
    ], axis=1).astype(np.int64)
    triple_set = set(map(tuple, triples.tolist()))
    return KGData(entities, relations, ent2id, rel2id, triples, triple_set)

def split_triples(triples: np.ndarray, train_ratio: float, val_ratio: float, seed: int):
    rng = np.random.default_rng(seed)
    idx = np.arange(len(triples))
    rng.shuffle(idx)
    triples = triples[idx]
    n = len(triples)
    n_train = int(n * train_ratio)
    n_val = int(n * val_ratio)
    train = triples[:n_train]
    val = triples[n_train:n_train + n_val]
    test = triples[n_train + n_val:]
    return train, val, test
