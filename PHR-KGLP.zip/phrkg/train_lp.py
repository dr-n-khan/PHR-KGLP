from __future__ import annotations
from typing import Dict, Tuple
import numpy as np
import torch
import torch.nn.functional as F
from torch.optim import Adam

from .model import RGCNEncoder, ModelConfig, distmult_score
from .utils import EarlyStopper

def build_pyg_edges(triples: np.ndarray) -> Tuple[torch.Tensor, torch.Tensor]:
    h = torch.from_numpy(triples[:, 0]).long()
    r = torch.from_numpy(triples[:, 1]).long()
    t = torch.from_numpy(triples[:, 2]).long()
    return torch.stack([h, t], dim=0), r

def sample_negatives(pos: torch.Tensor, num_entities: int, neg_ratio: int, rng: np.random.Generator) -> torch.Tensor:
    b = pos.size(0)
    total = b * neg_ratio
    neg = pos.repeat_interleave(neg_ratio, dim=0).clone()
    corrupt_head = rng.random(total) < 0.5
    rand_ents = torch.from_numpy(rng.integers(0, num_entities, size=total, dtype=np.int64)).long().to(pos.device)
    neg[corrupt_head, 0] = rand_ents[corrupt_head]
    neg[~corrupt_head, 2] = rand_ents[~corrupt_head]
    return neg

def margin_ranking_loss(pos_scores: torch.Tensor, neg_scores: torch.Tensor, gamma: float) -> torch.Tensor:
    b = pos_scores.size(0)
    k = neg_scores.numel() // b
    pos_rep = pos_scores.repeat_interleave(k)
    return F.relu(gamma - pos_rep + neg_scores.view(-1)).mean()

def train_link_prediction(train_triples: np.ndarray, val_triples: np.ndarray, num_entities: int, num_relations: int,
                          cfg_train: Dict, device: torch.device, seed: int, eval_fn):
    rng = np.random.default_rng(seed)
    mcfg = ModelConfig(
        num_entities=num_entities,
        num_relations=num_relations,
        hidden_dim=int(cfg_train["hidden_dim"]),
        num_layers=int(cfg_train["num_layers"]),
        dropout=float(cfg_train["dropout"]),
    )
    model = RGCNEncoder(mcfg).to(device)
    opt = Adam(model.parameters(), lr=float(cfg_train["lr"]), weight_decay=float(cfg_train["weight_decay"]))

    edge_index, edge_type = build_pyg_edges(train_triples)
    edge_index, edge_type = edge_index.to(device), edge_type.to(device)

    stopper = EarlyStopper(patience=int(cfg_train["patience"]))
    best_state, best_val = None, float("-inf")

    train_tensor = torch.from_numpy(train_triples).long().to(device)
    batch_size = int(cfg_train["batch_size"])
    epochs = int(cfg_train["epochs"])

    for _epoch in range(1, epochs + 1):
        model.train()
        perm = torch.randperm(train_tensor.size(0), device=device)

        for i in range(0, train_tensor.size(0), batch_size):
            pos = train_tensor[perm[i:i + batch_size]]
            neg = sample_negatives(pos, num_entities, int(cfg_train["neg_ratio"]), rng)

            ent_emb, rel_emb = model(edge_index, edge_type)
            pos_scores = distmult_score(ent_emb[pos[:, 0]], rel_emb[pos[:, 1]], ent_emb[pos[:, 2]])
            neg_scores = distmult_score(ent_emb[neg[:, 0]], rel_emb[neg[:, 1]], ent_emb[neg[:, 2]])

            loss = margin_ranking_loss(pos_scores, neg_scores, float(cfg_train["margin_gamma"]))
            opt.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=float(cfg_train["grad_clip"]))
            opt.step()

        model.eval()
        with torch.no_grad():
            val_m = eval_fn(model, val_triples)

        if val_m["MRR"] > best_val:
            best_val = val_m["MRR"]
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

        if stopper.step(val_m["MRR"]):
            break

    if best_state is not None:
        model.load_state_dict(best_state)
    return model
