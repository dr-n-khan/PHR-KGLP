from __future__ import annotations
import os
from typing import Dict, Any, List
import torch
from tqdm import tqdm

from .utils import seed_all, load_yaml, ensure_dir, get_device, save_yaml
from .data import load_triples_csv, build_kg, split_triples
from .train_lp import train_link_prediction
from .eval_lp import evaluate_link_prediction
from .metrics import aggregate_seed_metrics

def run_from_config(config_path: str) -> None:
    cfg = load_yaml(config_path)
    out_dir = cfg["outputs"]["dir"]
    ensure_dir(out_dir)
    device = get_device(cfg["training"]["device"])

    df = load_triples_csv(
        path=cfg["dataset"]["triples_path"],
        sep=cfg["dataset"]["sep"],
        head_col=cfg["dataset"]["head_col"],
        rel_col=cfg["dataset"]["rel_col"],
        tail_col=cfg["dataset"]["tail_col"],
    )
    kg = build_kg(df)
    seeds: List[int] = list(cfg["training"]["seeds"])
    seed_metrics: List[Dict[str, float]] = []

    for sd in tqdm(seeds, desc=f"Seeds ({cfg['dataset']['name']})"):
        seed_all(sd)
        train, val, test = split_triples(
            kg.triples,
            train_ratio=float(cfg["split"]["train"]),
            val_ratio=float(cfg["split"]["val"]),
            seed=sd
        )

        def eval_fn(model, eval_triples):
            return evaluate_link_prediction(
                model=model,
                eval_triples=eval_triples,
                train_triples=train,
                num_entities=len(kg.entities),
                filtered=bool(cfg["split"]["filtered_eval"]),
                ks=list(cfg["eval"]["ks"]),
                max_candidates=int(cfg["eval"]["max_candidates"]),
            )

        model = train_link_prediction(
            train_triples=train,
            val_triples=val,
            num_entities=len(kg.entities),
            num_relations=len(kg.relations),
            cfg_train=cfg["training"],
            device=device,
            seed=sd,
            eval_fn=eval_fn
        )

        with torch.no_grad():
            test_m = evaluate_link_prediction(
                model=model,
                eval_triples=test,
                train_triples=train,
                num_entities=len(kg.entities),
                filtered=bool(cfg["split"]["filtered_eval"]),
                ks=list(cfg["eval"]["ks"]),
                max_candidates=int(cfg["eval"]["max_candidates"]),
            )
        seed_metrics.append(test_m)

        if cfg["outputs"].get("save_model", True):
            torch.save(model.state_dict(), os.path.join(out_dir, f"model_seed{sd}.pt"))

    agg = aggregate_seed_metrics(seed_metrics)
    report: Dict[str, Any] = {
        "dataset": cfg["dataset"]["name"],
        "n_seeds": len(seeds),
        "seed_metrics": seed_metrics,
        "mean_ci95": {k: {"mean": v[0], "ci95": v[1]} for k, v in agg.items()}
    }
    save_yaml(report, os.path.join(out_dir, "report.yaml"))

    print(f"\n=== {cfg['dataset']['name']} Test (mean ± 95% CI) over {len(seeds)} runs ===")
    for m, (mean, ci) in agg.items():
        print(f"{m:6s}: {mean:.4f} ± {ci:.4f}")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", type=str, required=True, help="Path to YAML config")
    args = ap.parse_args()
    run_from_config(args.config)
