from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import RGCNConv

@dataclass
class ModelConfig:
    num_entities: int
    num_relations: int
    hidden_dim: int = 200
    num_layers: int = 2
    dropout: float = 0.3

class RGCNEncoder(nn.Module):
    """R-GCN encoder that produces entity embeddings; relations are learned as embeddings."""
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.entity_emb = nn.Embedding(cfg.num_entities, cfg.hidden_dim)
        self.rel_emb = nn.Embedding(cfg.num_relations, cfg.hidden_dim)
        self.convs = nn.ModuleList([
            RGCNConv(cfg.hidden_dim, cfg.hidden_dim, num_relations=cfg.num_relations)
            for _ in range(cfg.num_layers)
        ])
        self.dropout = nn.Dropout(cfg.dropout)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        nn.init.xavier_uniform_(self.entity_emb.weight)
        nn.init.xavier_uniform_(self.rel_emb.weight)
        for c in self.convs:
            c.reset_parameters()

    def forward(self, edge_index: torch.Tensor, edge_type: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        x = self.entity_emb.weight
        for conv in self.convs:
            x = conv(x, edge_index, edge_type)
            x = F.relu(x)
            x = self.dropout(x)
        return x, self.rel_emb.weight

def distmult_score(h: torch.Tensor, r: torch.Tensor, t: torch.Tensor) -> torch.Tensor:
    return torch.sum(h * r * t, dim=-1)
