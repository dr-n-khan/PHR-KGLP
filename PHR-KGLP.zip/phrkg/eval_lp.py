from __future__ import annotations
from typing import Dict, List
import numpy as np
import torch
from tqdm import tqdm

from .model import distmult_score, RGCNEncoder
from .train_lp import build_pyg_edges

def _rank(scores: torch.Tensor, true_index: int) -> int:
    target = scores[true_index].item()
    return 1 + int(torch.sum(scores > target).item())

def evaluate_link_prediction(model: RGCNEncoder, eval_triples: np.ndarray, train_triples: np.ndarray,
                             num_entities: int, filtered: bool = True, ks: List[int] = [1,3,10],
                             max_candidates: int = 0) -> Dict[str, float]:
    device = next(model.parameters()).device
    edge_index, edge_type = build_pyg_edges(train_triples)
    edge_index, edge_type = edge_index.to(device), edge_type.to(device)

    known = set(map(tuple, np.concatenate([train_triples, eval_triples], axis=0).tolist()))
    ent_emb, rel_emb = model(edge_index, edge_type)

    ranks = []
    rng = np.random.default_rng(12345)

    for (h, r, t) in tqdm(eval_triples, desc="Eval LP", leave=False):
        h = int(h); r = int(r); t = int(t)

        cand = (rng.choice(num_entities, size=max_candidates, replace=False)
                if (max_candidates and max_candidates < num_entities)
                else np.arange(num_entities, dtype=np.int64))
        if t not in cand:
            cand[0] = t
        cand = np.unique(cand)

        cand_t = torch.from_numpy(cand).long().to(device)
        scores = distmult_score(
            ent_emb[torch.tensor([h], device=device)].repeat(cand_t.size(0), 1),
            rel_emb[torch.tensor([r], device=device)].repeat(cand_t.size(0), 1),
            ent_emb[cand_t]
        )
        if filtered:
            scores = scores.clone()
            for i, tc in enumerate(cand):
                if tc != t and (h, r, int(tc)) in known:
                    scores[i] = -1e9
        true_idx = int(np.where(cand == t)[0][0])
        ranks.append(_rank(scores, true_idx))

        # head prediction
        cand_h = (rng.choice(num_entities, size=max_candidates, replace=False)
                  if (max_candidates and max_candidates < num_entities)
                  else np.arange(num_entities, dtype=np.int64))
        if h not in cand_h:
            cand_h[0] = h
        cand_h = np.unique(cand_h)

        cand_h_t = torch.from_numpy(cand_h).long().to(device)
        scores_h = distmult_score(
            ent_emb[cand_h_t],
            rel_emb[torch.tensor([r], device=device)].repeat(cand_h_t.size(0), 1),
            ent_emb[torch.tensor([t], device=device)].repeat(cand_h_t.size(0), 1)
        )
        if filtered:
            scores_h = scores_h.clone()
            for i, hc in enumerate(cand_h):
                if hc != h and (int(hc), r, t) in known:
                    scores_h[i] = -1e9
        true_idx_h = int(np.where(cand_h == h)[0][0])
        ranks.append(_rank(scores_h, true_idx_h))

    ranks = np.asarray(ranks, dtype=np.int64)
    out = {"MRR": float(np.mean(1.0 / ranks))}
    for k in ks:
        out[f"HR@{k}"] = float(np.mean(ranks <= k))
    return out
