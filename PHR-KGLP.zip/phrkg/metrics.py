from __future__ import annotations
import math
from typing import Dict, List, Tuple
import numpy as np

def mean_ci95(values: List[float]) -> Tuple[float, float]:
    """Return (mean, 95% CI half-width) using Student's t critical value."""
    n = len(values)
    mean = float(np.mean(values)) if n else 0.0
    if n < 2:
        return mean, 0.0
    sd = float(np.std(values, ddof=1))
    # t_{0.975, df} for df=1..10 (fallback to ~1.96 for larger df)
    t_table = {1:12.706,2:4.303,3:3.182,4:2.776,5:2.571,6:2.447,7:2.365,8:2.306,9:2.262,10:2.228}
    df = n - 1
    tcrit = t_table.get(df, 1.96)
    ci = tcrit * sd / math.sqrt(n)
    return mean, float(ci)

def aggregate_seed_metrics(seed_results: List[Dict[str, float]]) -> Dict[str, Tuple[float, float]]:
    metrics = seed_results[0].keys() if seed_results else []
    out: Dict[str, Tuple[float, float]] = {}
    for m in metrics:
        vals = [sr[m] for sr in seed_results]
        out[m] = mean_ci95(vals)
    return out
