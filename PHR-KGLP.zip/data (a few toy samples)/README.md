# Data

This repository ships toy examples so the pipeline runs out of the box.

For real experiments, you should:
1) Download your data sources locally (respecting licenses/IRB).
2) Convert them to a triple CSV with columns: `head, relation, tail`.
3) Point `configs/*.yaml` to your triple file path.


## Licensing note
Do not upload licensed sources (e.g., SNOMED-CT, DrugBank) to GitHub.

Upload only:
- preprocessing scripts
- derived anonymized triples if permitted
- toy/sample subsets