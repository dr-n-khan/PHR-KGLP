#!/usr/bin/env bash
set -e
python -m phrkg.run_experiments --config configs/hkg.yaml
